---
navigation:
  title: Markdown 测试
---

# Markdown 测试

## 行内格式

| Markdown | 另一种写法 | 效果 |
| --- | --- | --- |
| `*Italic*` | `_Italic_` | *Italic* |
| `**Bold**` | `__Bold__` | **Bold** |
| `~~Strikethrough~~` | `~Strikethrough~` | ~~Strikethrough~~ |
| `[Link](http://a.com)` |  | [Link](http://a.com) |
| `[Relative Link](./index.md)` |  | [Link](./index.md) |
| `[Absolute Link](guidenh:index.md)` |  | [Absolute Link](guidenh:index.md) |
| `` `Inline Code` `` |  | `Inline Code` |
| `![Image](test1.png)` |  | ![Image](test1.png) |

自动链接：访问 https://example.com/docs、www.example.org 或 guide@example.com

## 标题

标题可以通过前缀 `#` 定义。

# 一级标题

## 二级标题

### 三级标题

#### 四级标题

##### 五级标题

###### 六级标题

## 其他块元素

分隔线：

Markdown：

```
---
```

效果：

---

Markdown：

`> Blockquote`

效果：

> Blockquote

> [!NOTE]
> GitHub 风格提示引用块。

## 列表

Markdown：

```
* List
* List
* List

1. One
2. Two
3. Three

- [x] 已完成任务
- [ ] 待处理任务

<Column width="220">
- 限宽列表示例
- 另一条限宽列表项
</Column>
```

效果：

* List
* List
* List

1. One
2. Two
3. Three

## 表格

Markdown：

```
| First Header  | Second Header |
| ------------- | ------------- |
| Content Cell  | Content Cell  |
| Content Cell  | Content Cell  |
```

效果：

| First Header  | Second Header |
| ------------- | ------------- |
| Content Cell  | Content Cell  |
| Content Cell  | Content Cell  |

普通 Markdown 表格也可以使用运行时列宽 hint：

| Name | Value |
| --- | --- |
| Iron | 42 |
| Gold | 17 |
{: widths="120,80" }

## 引用式链接与图片

[Guide Ref][doc]

![Machine Diagram][img]

[doc]: ./subpage.md#top
[img]: test1.png "Machine Diagram"

## 原生 HTML 片段

Press <kbd>Shift</kbd> + <sub>1</sub>

<a href="./subpage.md" title="Open subpage">Open subpage</a><br clear="all" />

<details open>
<summary>More</summary>

Body text inside runtime details.
</details>

## 代码块

```lua
local value = 42
print(value)
```

这个未标注语言的围栏仍然会保持为代码块，但 GuideNH 会自动识别语言：

```
object Demo extends App {
  println("auto detected scala")
}
```

    print("indented code block")

这个显式 `csv` 围栏会渲染成运行时表格：

```csv
name,value
iron,42
gold,17
```

这个显式 `csv` 围栏还会应用列宽 hint：

```csv widths=120,80
name,value
iron,42
gold,17
```

## Mermaid 思维导图

```mermaid
mindmap
  root((GuideNH))
    Runtime
      Markdown
      CSV
    Mindmap::icon(fa fa-sitemap)
      Drag to pan
```

<Mermaid src="./markdown-mindmap.mmd" />

## CSV 表格导入

<CsvTable src="./markdown-table.csv" />

<CsvTable src="./markdown-table.csv" widths="120,80" />

## 脚注

脚注引用[^one]

[^one]: 这是脚注提示内容
