---
navigation:
  title: Markdown Test
---

# Markdown Test

## Inline Formatting

| Markdown                            | Alternative       | Result                            |
|-------------------------------------|-------------------|-----------------------------------|
| `*Italic*`                          | `_Italic_`        | *Italic*                          |
| `**Bold**`                          | `__Bold__`        | **Bold**                          |
| `~~Strikethrough~~`                 | `~Strikethrough~` | ~~Strikethrough~~                 |
| `[Link](http://a.com)`              |                   | [Link](http://a.com)              |
| `[Relative Link](./index.md)`       |                   | [Link](./index.md)                |
| `[Absolute Link](guidenh:index.md)` |                   | [Absolute Link](guidenh:index.md) |
| `` `Inline Code` ``                 |                   | `Inline Code`                     |
| `![Image](test1.png)`               |                   | ![Image](test1.png)               |

Literal autolinks: visit https://example.com/docs, www.example.org, or guide@example.com

## Headings

Headings can be defined by prefixing them with `#`.

# Heading 1

## Heading 2

### Heading 3

#### Heading 4

##### Heading 5

###### Heading 6

## Other Block Elements

Horizontal Rule:

Markdown:

```
---
```

Result:

---

Markdown:

`> Blockquote`

Result:

> Blockquote 

> [!NOTE]
> GitHub-style alert blockquote.

## Lists

Markdown:

```
* List
* List
* List 

1. One
2. Two
3. Three
```

Result:

* List
* List
* List 

1. One
2. Two
3. Three

- [x] Task done
- [ ] Task pending

<Column width="220">
- constrained list line width example
- another constrained list item
</Column>

## Tables

Markdown:

```
| First Header  | Second Header |
| ------------- | ------------- |
| Content Cell  | Content Cell  |
| Content Cell  | Content Cell  |
```

Result:

| First Header  | Second Header |
| ------------- | ------------- |
| Content Cell  | Content Cell  |
| Content Cell  | Content Cell  |

Ordinary markdown tables can also use runtime width hints:

| Name | Value |
| --- | --- |
| Iron | 42 |
| Gold | 17 |
{: widths="120,80" }

## Reference Links And Images

[Guide Ref][doc]

![Machine Diagram][img]

[doc]: ./subpage.md#top
[img]: test1.png "Machine Diagram"

## Raw HTML Fragments

Press <kbd>Shift</kbd> + <sub>1</sub>

<a href="./subpage.md" title="Open subpage">Open subpage</a><br clear="all" />

<details open>
<summary>More</summary>

Body text inside runtime details.
</details>

## Code Blocks

```lua
local value = 42
print(value)
```

This unlabeled fence still stays a code block, but GuideNH auto-detects the language:

```
object Demo extends App {
  println("auto detected scala")
}
```

    print("indented code block")

This explicit `csv` fence renders as a runtime table:

```csv
name,value
iron,42
gold,17
```

This explicit `csv` fence also applies column width hints:

```csv widths=120,80
name,value
iron,42
gold,17
```

## Mermaid Mindmaps

```mermaid
mindmap
  root((GuideNH))
    Runtime
      Markdown
      CSV
    Mindmap::icon(fa fa-sitemap)
      Drag to pan
```

<Mermaid src="./markdown-mindmap.mmd" />

## CSV Table Import

<CsvTable src="./markdown-table.csv" />

<CsvTable src="./markdown-table.csv" widths="120,80" />

## Footnotes

Footnote ref[^one]

[^one]: tooltip text for the footnote
